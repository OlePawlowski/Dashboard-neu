const form = document.getElementById("profileForm");
const pdfButton = document.getElementById("pdfButton");
const resetButton = document.getElementById("resetButton");
const photoInput = document.getElementById("photoInput");
const photoPreview = document.getElementById("photoPreview");
const photoPlaceholder = document.getElementById("photoPlaceholder");
const editableFields = Array.from(form.querySelectorAll("[contenteditable='true']"));
const checkboxFields = Array.from(form.querySelectorAll('input[type="checkbox"]'));
const defaultPdfButtonLabel = pdfButton.textContent;
let isExportingPdf = false;

function syncCloneState(sourceRoot, cloneRoot) {
  const sourceCheckboxes = sourceRoot.querySelectorAll('input[type="checkbox"]');
  const cloneCheckboxes = cloneRoot.querySelectorAll('input[type="checkbox"]');
  const sourcePhoto = sourceRoot.querySelector("#photoPreview");
  const clonePhoto = cloneRoot.querySelector("#photoPreview");
  const clonePlaceholder = cloneRoot.querySelector("#photoPlaceholder");

  sourceCheckboxes.forEach((checkbox, index) => {
    const cloneCheckbox = cloneCheckboxes[index];

    if (cloneCheckbox) {
      cloneCheckbox.checked = checkbox.checked;
    }
  });

  if (sourcePhoto && clonePhoto) {
    clonePhoto.src = sourcePhoto.src;
    clonePhoto.className = sourcePhoto.className;
  }

  if (clonePlaceholder) {
    clonePlaceholder.classList.toggle(
      "is-hidden",
      Boolean(sourcePhoto && sourcePhoto.classList.contains("is-visible"))
    );
  }
}

function setPlainTextContent(element, value) {
  element.textContent = value;
}

function resetEditableFields() {
  editableFields.forEach((field) => {
    setPlainTextContent(field, field.dataset.default || "");
  });
}

function resetCheckboxes() {
  checkboxFields.forEach((checkbox) => {
    checkbox.checked = true;
  });
}

function clearPhoto() {
  photoPreview.removeAttribute("src");
  photoPreview.classList.remove("is-visible");
  photoPlaceholder.classList.remove("is-hidden");
  photoInput.value = "";
}

function updatePhotoPreview(dataUrl) {
  photoPreview.src = dataUrl;
  photoPreview.classList.add("is-visible");
  photoPlaceholder.classList.add("is-hidden");
}

function sanitizeFileName(value) {
  const normalized = value
    .trim()
    .toLowerCase()
    .replace(/ä/g, "ae")
    .replace(/ö/g, "oe")
    .replace(/ü/g, "ue")
    .replace(/ß/g, "ss")
    .replace(/\s+/g, "-");
  const safe = normalized.replace(/[^a-z0-9-]/g, "");

  return safe || "profil";
}

function setPdfButtonState(isBusy) {
  pdfButton.disabled = isBusy;
  pdfButton.textContent = isBusy ? "PDF wird erstellt..." : defaultPdfButtonLabel;
}

async function waitForImages(root) {
  const images = Array.from(root.querySelectorAll("img"));

  await Promise.all(
    images.map((image) => new Promise((resolve) => {
      if (image.complete) {
        resolve();
        return;
      }

      image.addEventListener("load", resolve, { once: true });
      image.addEventListener("error", resolve, { once: true });
    }))
  );
}

async function exportPdf() {
  if (isExportingPdf) {
    return;
  }

  const jsPdfConstructor = window.jspdf?.jsPDF || window.jsPDF;

  if (typeof html2canvas === "undefined" || typeof jsPdfConstructor !== "function") {
    window.alert("PDF-Export ist aktuell nicht verfügbar.");
    return;
  }

  isExportingPdf = true;
  setPdfButtonState(true);

  const exportWrapper = document.createElement("div");
  const exportClone = form.cloneNode(true);
  const exportNameElement = form.querySelector("[data-export-name='true']");
  const fileName = sanitizeFileName(exportNameElement?.textContent || "profil");
  const a4WidthPx = 794;
  const a4HeightPx = 1123;

  exportWrapper.className = "pdf-mode";
  exportWrapper.style.position = "fixed";
  exportWrapper.style.left = "-200vw";
  exportWrapper.style.top = "0";
  exportWrapper.style.width = `${a4WidthPx}px`;
  exportWrapper.style.height = `${a4HeightPx}px`;
  exportWrapper.style.pointerEvents = "none";
  exportWrapper.style.overflow = "hidden";
  exportWrapper.style.background = "#ffffff";

  syncCloneState(form, exportClone);
  exportClone.style.width = "210mm";
  exportClone.style.height = "297mm";
  exportClone.style.borderRadius = "0";
  exportClone.style.boxShadow = "none";
  exportWrapper.appendChild(exportClone);
  document.body.appendChild(exportWrapper);

  try {
    if (document.fonts?.ready) {
      await document.fonts.ready;
    }

    await waitForImages(exportClone);

    const { width, height } = exportClone.getBoundingClientRect();
    const scale = Math.min(1, a4WidthPx / width, a4HeightPx / height);

    exportClone.style.transformOrigin = "top left";
    exportClone.style.transform = `scale(${scale})`;
    exportClone.style.marginLeft = `${(a4WidthPx - width * scale) / 2}px`;
    exportClone.style.marginTop = `${(a4HeightPx - height * scale) / 2}px`;

    await new Promise((resolve) => requestAnimationFrame(() => resolve()));

    const canvas = await html2canvas(exportWrapper, {
      scale: 2,
      useCORS: true,
      backgroundColor: "#f2ebe3",
    });

    const pdf = new jsPdfConstructor({
      unit: "mm",
      format: "a4",
      orientation: "portrait",
    });

    const imageData = canvas.toDataURL("image/jpeg", 0.98);
    pdf.addImage(imageData, "JPEG", 0, 0, 210, 297);
    const blob = pdf.output("blob");
    const downloadUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = downloadUrl;
    link.download = `betreuungskraftprofil-${fileName}.pdf`;
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();

    window.setTimeout(() => {
      URL.revokeObjectURL(downloadUrl);
      link.remove();
    }, 1000);
  } catch (error) {
    console.error("PDF-Export fehlgeschlagen", error);
    window.alert("Beim Erstellen der PDF ist ein Fehler aufgetreten.");
  } finally {
    exportWrapper.remove();
    document
      .querySelectorAll(".html2pdf__container, .html2canvas-container")
      .forEach((node) => node.remove());
    setPdfButtonState(false);
    isExportingPdf = false;
  }
}

function resetForm() {
  resetEditableFields();
  resetCheckboxes();
  clearPhoto();
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
});

form.addEventListener("keydown", (event) => {
  const target = event.target;

  if (!(target instanceof HTMLElement)) {
    return;
  }

  if (target.matches("[contenteditable='true'][data-inline='true']") && event.key === "Enter") {
    event.preventDefault();
  }
});

form.addEventListener("paste", (event) => {
  const target = event.target;

  if (!(target instanceof HTMLElement) || !target.matches("[contenteditable='true']")) {
    return;
  }

  event.preventDefault();
  const text = event.clipboardData?.getData("text/plain") || "";
  document.execCommand("insertText", false, text);
});

form.addEventListener("click", (event) => {
  const target = event.target;

  if (!(target instanceof HTMLElement) || !target.matches("[contenteditable='true']")) {
    return;
  }

  event.stopPropagation();
});

form.addEventListener("mousedown", (event) => {
  const target = event.target;

  if (!(target instanceof HTMLElement) || !target.matches("[contenteditable='true']")) {
    return;
  }

  event.stopPropagation();
});

photoInput.addEventListener("change", () => {
  const file = photoInput.files?.[0];

  if (!file) {
    clearPhoto();
    return;
  }

  const reader = new FileReader();
  reader.addEventListener("load", () => {
    if (typeof reader.result === "string") {
      updatePhotoPreview(reader.result);
    }
  });
  reader.readAsDataURL(file);
});

pdfButton.addEventListener("click", exportPdf);
resetButton.addEventListener("click", resetForm);
